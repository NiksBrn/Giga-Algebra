/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../sources/mainwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "on_tabWidget_tabBarClicked",
    "",
    "index",
    "on_pushButton_15_clicked",
    "on_COM_NN_D_BUTTON_clicked",
    "on_NZER_N_B_BUTTON_clicked",
    "on_ADD_1N_N_BUTTON_clicked",
    "on_ADD_NN_N_BUTTON_clicked",
    "on_SUB_NN_N_BUTTON_clicked",
    "on_MOD_NN_N_BUTTON_clicked",
    "on_DIV_NN_N_BUTTON_clicked",
    "on_GCF_NN_N_BUTTON_clicked",
    "on_LCM_NN_N_BUTTON_clicked",
    "on_DIV_NN_Dk_BUTTON_clicked",
    "on_SUB_NDN_N_BUTTON_clicked",
    "on_MUL_ND_N_BUTTON_clicked",
    "on_MUL_Nk_N_BUTTON_clicked",
    "on_MUL_NN_N_BUTTON_clicked",
    "on_actionOpen_Input_File_triggered",
    "on_actionChoose_Output_File_triggered",
    "write_natural_result",
    "NaturalNumber",
    "a",
    "write_integer_result",
    "IntegerNumber",
    "write_rational_result",
    "RationalNumber",
    "write_polynomial_result",
    "Polynomial",
    "on_actionOpen_Input2_File_triggered",
    "on_pushButton_16_clicked",
    "on_MUL_ZZ_Z_BUTTON_clicked",
    "on_ADD_ZZ_Z_BUTTON_clicked",
    "on_SUB_ZZ_Z_BUTTON_clicked",
    "on_ABS_Z_N_BUTTON_clicked",
    "on_TRANS_N_Z_BUTTON_clicked",
    "on_TRANS_Z_N_BUTTON_clicked",
    "on_POZ_Z_D_BUTTON_clicked",
    "on_MUL_ZM_Z_BUTTON_clicked",
    "on_DIV_ZZ_Z_BUTTON_clicked",
    "on_MOD_ZZ_Z_BUTTON_clicked",
    "on_MUL_QQ_Q_BUTTON_clicked",
    "on_INT_Q_B_BUTTON_clicked",
    "on_RED_Q_Q_BUTTON_clicked",
    "on_ADD_QQ_Q_BUTTON_clicked",
    "on_TRANS_Z_Q_BUTTON_clicked",
    "on_DIV_QQ_Q_BUTTON_clicked",
    "on_SUB_QQ_Q_BUTTON_clicked",
    "on_TRANS_Q_Z_BUTTON_clicked",
    "on_pushButton_17_clicked",
    "show_second_rational",
    "show_second_integer",
    "show_second_natural",
    "on_pushButton_18_clicked",
    "on_MUL_PP_P_BUTTON_clicked",
    "on_NMR_P_P_clicked",
    "on_ADD_PP_P_BUTTON_clicked",
    "on_SUB_PP_P_BUTTON_clicked",
    "on_GCF_PP_P_BUTTON_clicked",
    "on_DER_P_P_clicked",
    "on_FAC_P_Q_BUTTON_clicked",
    "on_LED_P_Q_BUTTON_clicked",
    "on_DEG_P_N_BUTTON_clicked",
    "on_MUL_PQ_P_BUTTON_clicked",
    "on_DIV_PP_P_BUTTON_clicked",
    "on_MUL_PXK_BUTTON_clicked",
    "on_MOD_PP_P_BUTTON_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[136];
    char stringdata0[11];
    char stringdata1[27];
    char stringdata2[1];
    char stringdata3[6];
    char stringdata4[25];
    char stringdata5[27];
    char stringdata6[27];
    char stringdata7[27];
    char stringdata8[27];
    char stringdata9[27];
    char stringdata10[27];
    char stringdata11[27];
    char stringdata12[27];
    char stringdata13[27];
    char stringdata14[28];
    char stringdata15[28];
    char stringdata16[27];
    char stringdata17[27];
    char stringdata18[27];
    char stringdata19[35];
    char stringdata20[38];
    char stringdata21[21];
    char stringdata22[14];
    char stringdata23[2];
    char stringdata24[21];
    char stringdata25[14];
    char stringdata26[22];
    char stringdata27[15];
    char stringdata28[24];
    char stringdata29[11];
    char stringdata30[36];
    char stringdata31[25];
    char stringdata32[27];
    char stringdata33[27];
    char stringdata34[27];
    char stringdata35[26];
    char stringdata36[28];
    char stringdata37[28];
    char stringdata38[26];
    char stringdata39[27];
    char stringdata40[27];
    char stringdata41[27];
    char stringdata42[27];
    char stringdata43[26];
    char stringdata44[26];
    char stringdata45[27];
    char stringdata46[28];
    char stringdata47[27];
    char stringdata48[27];
    char stringdata49[28];
    char stringdata50[25];
    char stringdata51[21];
    char stringdata52[20];
    char stringdata53[20];
    char stringdata54[25];
    char stringdata55[27];
    char stringdata56[19];
    char stringdata57[27];
    char stringdata58[27];
    char stringdata59[27];
    char stringdata60[19];
    char stringdata61[26];
    char stringdata62[26];
    char stringdata63[26];
    char stringdata64[27];
    char stringdata65[27];
    char stringdata66[26];
    char stringdata67[27];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 26),  // "on_tabWidget_tabBarClicked"
        QT_MOC_LITERAL(38, 0),  // ""
        QT_MOC_LITERAL(39, 5),  // "index"
        QT_MOC_LITERAL(45, 24),  // "on_pushButton_15_clicked"
        QT_MOC_LITERAL(70, 26),  // "on_COM_NN_D_BUTTON_clicked"
        QT_MOC_LITERAL(97, 26),  // "on_NZER_N_B_BUTTON_clicked"
        QT_MOC_LITERAL(124, 26),  // "on_ADD_1N_N_BUTTON_clicked"
        QT_MOC_LITERAL(151, 26),  // "on_ADD_NN_N_BUTTON_clicked"
        QT_MOC_LITERAL(178, 26),  // "on_SUB_NN_N_BUTTON_clicked"
        QT_MOC_LITERAL(205, 26),  // "on_MOD_NN_N_BUTTON_clicked"
        QT_MOC_LITERAL(232, 26),  // "on_DIV_NN_N_BUTTON_clicked"
        QT_MOC_LITERAL(259, 26),  // "on_GCF_NN_N_BUTTON_clicked"
        QT_MOC_LITERAL(286, 26),  // "on_LCM_NN_N_BUTTON_clicked"
        QT_MOC_LITERAL(313, 27),  // "on_DIV_NN_Dk_BUTTON_clicked"
        QT_MOC_LITERAL(341, 27),  // "on_SUB_NDN_N_BUTTON_clicked"
        QT_MOC_LITERAL(369, 26),  // "on_MUL_ND_N_BUTTON_clicked"
        QT_MOC_LITERAL(396, 26),  // "on_MUL_Nk_N_BUTTON_clicked"
        QT_MOC_LITERAL(423, 26),  // "on_MUL_NN_N_BUTTON_clicked"
        QT_MOC_LITERAL(450, 34),  // "on_actionOpen_Input_File_trig..."
        QT_MOC_LITERAL(485, 37),  // "on_actionChoose_Output_File_t..."
        QT_MOC_LITERAL(523, 20),  // "write_natural_result"
        QT_MOC_LITERAL(544, 13),  // "NaturalNumber"
        QT_MOC_LITERAL(558, 1),  // "a"
        QT_MOC_LITERAL(560, 20),  // "write_integer_result"
        QT_MOC_LITERAL(581, 13),  // "IntegerNumber"
        QT_MOC_LITERAL(595, 21),  // "write_rational_result"
        QT_MOC_LITERAL(617, 14),  // "RationalNumber"
        QT_MOC_LITERAL(632, 23),  // "write_polynomial_result"
        QT_MOC_LITERAL(656, 10),  // "Polynomial"
        QT_MOC_LITERAL(667, 35),  // "on_actionOpen_Input2_File_tri..."
        QT_MOC_LITERAL(703, 24),  // "on_pushButton_16_clicked"
        QT_MOC_LITERAL(728, 26),  // "on_MUL_ZZ_Z_BUTTON_clicked"
        QT_MOC_LITERAL(755, 26),  // "on_ADD_ZZ_Z_BUTTON_clicked"
        QT_MOC_LITERAL(782, 26),  // "on_SUB_ZZ_Z_BUTTON_clicked"
        QT_MOC_LITERAL(809, 25),  // "on_ABS_Z_N_BUTTON_clicked"
        QT_MOC_LITERAL(835, 27),  // "on_TRANS_N_Z_BUTTON_clicked"
        QT_MOC_LITERAL(863, 27),  // "on_TRANS_Z_N_BUTTON_clicked"
        QT_MOC_LITERAL(891, 25),  // "on_POZ_Z_D_BUTTON_clicked"
        QT_MOC_LITERAL(917, 26),  // "on_MUL_ZM_Z_BUTTON_clicked"
        QT_MOC_LITERAL(944, 26),  // "on_DIV_ZZ_Z_BUTTON_clicked"
        QT_MOC_LITERAL(971, 26),  // "on_MOD_ZZ_Z_BUTTON_clicked"
        QT_MOC_LITERAL(998, 26),  // "on_MUL_QQ_Q_BUTTON_clicked"
        QT_MOC_LITERAL(1025, 25),  // "on_INT_Q_B_BUTTON_clicked"
        QT_MOC_LITERAL(1051, 25),  // "on_RED_Q_Q_BUTTON_clicked"
        QT_MOC_LITERAL(1077, 26),  // "on_ADD_QQ_Q_BUTTON_clicked"
        QT_MOC_LITERAL(1104, 27),  // "on_TRANS_Z_Q_BUTTON_clicked"
        QT_MOC_LITERAL(1132, 26),  // "on_DIV_QQ_Q_BUTTON_clicked"
        QT_MOC_LITERAL(1159, 26),  // "on_SUB_QQ_Q_BUTTON_clicked"
        QT_MOC_LITERAL(1186, 27),  // "on_TRANS_Q_Z_BUTTON_clicked"
        QT_MOC_LITERAL(1214, 24),  // "on_pushButton_17_clicked"
        QT_MOC_LITERAL(1239, 20),  // "show_second_rational"
        QT_MOC_LITERAL(1260, 19),  // "show_second_integer"
        QT_MOC_LITERAL(1280, 19),  // "show_second_natural"
        QT_MOC_LITERAL(1300, 24),  // "on_pushButton_18_clicked"
        QT_MOC_LITERAL(1325, 26),  // "on_MUL_PP_P_BUTTON_clicked"
        QT_MOC_LITERAL(1352, 18),  // "on_NMR_P_P_clicked"
        QT_MOC_LITERAL(1371, 26),  // "on_ADD_PP_P_BUTTON_clicked"
        QT_MOC_LITERAL(1398, 26),  // "on_SUB_PP_P_BUTTON_clicked"
        QT_MOC_LITERAL(1425, 26),  // "on_GCF_PP_P_BUTTON_clicked"
        QT_MOC_LITERAL(1452, 18),  // "on_DER_P_P_clicked"
        QT_MOC_LITERAL(1471, 25),  // "on_FAC_P_Q_BUTTON_clicked"
        QT_MOC_LITERAL(1497, 25),  // "on_LED_P_Q_BUTTON_clicked"
        QT_MOC_LITERAL(1523, 25),  // "on_DEG_P_N_BUTTON_clicked"
        QT_MOC_LITERAL(1549, 26),  // "on_MUL_PQ_P_BUTTON_clicked"
        QT_MOC_LITERAL(1576, 26),  // "on_DIV_PP_P_BUTTON_clicked"
        QT_MOC_LITERAL(1603, 25),  // "on_MUL_PXK_BUTTON_clicked"
        QT_MOC_LITERAL(1629, 26)   // "on_MOD_PP_P_BUTTON_clicked"
    },
    "MainWindow",
    "on_tabWidget_tabBarClicked",
    "",
    "index",
    "on_pushButton_15_clicked",
    "on_COM_NN_D_BUTTON_clicked",
    "on_NZER_N_B_BUTTON_clicked",
    "on_ADD_1N_N_BUTTON_clicked",
    "on_ADD_NN_N_BUTTON_clicked",
    "on_SUB_NN_N_BUTTON_clicked",
    "on_MOD_NN_N_BUTTON_clicked",
    "on_DIV_NN_N_BUTTON_clicked",
    "on_GCF_NN_N_BUTTON_clicked",
    "on_LCM_NN_N_BUTTON_clicked",
    "on_DIV_NN_Dk_BUTTON_clicked",
    "on_SUB_NDN_N_BUTTON_clicked",
    "on_MUL_ND_N_BUTTON_clicked",
    "on_MUL_Nk_N_BUTTON_clicked",
    "on_MUL_NN_N_BUTTON_clicked",
    "on_actionOpen_Input_File_triggered",
    "on_actionChoose_Output_File_triggered",
    "write_natural_result",
    "NaturalNumber",
    "a",
    "write_integer_result",
    "IntegerNumber",
    "write_rational_result",
    "RationalNumber",
    "write_polynomial_result",
    "Polynomial",
    "on_actionOpen_Input2_File_triggered",
    "on_pushButton_16_clicked",
    "on_MUL_ZZ_Z_BUTTON_clicked",
    "on_ADD_ZZ_Z_BUTTON_clicked",
    "on_SUB_ZZ_Z_BUTTON_clicked",
    "on_ABS_Z_N_BUTTON_clicked",
    "on_TRANS_N_Z_BUTTON_clicked",
    "on_TRANS_Z_N_BUTTON_clicked",
    "on_POZ_Z_D_BUTTON_clicked",
    "on_MUL_ZM_Z_BUTTON_clicked",
    "on_DIV_ZZ_Z_BUTTON_clicked",
    "on_MOD_ZZ_Z_BUTTON_clicked",
    "on_MUL_QQ_Q_BUTTON_clicked",
    "on_INT_Q_B_BUTTON_clicked",
    "on_RED_Q_Q_BUTTON_clicked",
    "on_ADD_QQ_Q_BUTTON_clicked",
    "on_TRANS_Z_Q_BUTTON_clicked",
    "on_DIV_QQ_Q_BUTTON_clicked",
    "on_SUB_QQ_Q_BUTTON_clicked",
    "on_TRANS_Q_Z_BUTTON_clicked",
    "on_pushButton_17_clicked",
    "show_second_rational",
    "show_second_integer",
    "show_second_natural",
    "on_pushButton_18_clicked",
    "on_MUL_PP_P_BUTTON_clicked",
    "on_NMR_P_P_clicked",
    "on_ADD_PP_P_BUTTON_clicked",
    "on_SUB_PP_P_BUTTON_clicked",
    "on_GCF_PP_P_BUTTON_clicked",
    "on_DER_P_P_clicked",
    "on_FAC_P_Q_BUTTON_clicked",
    "on_LED_P_Q_BUTTON_clicked",
    "on_DEG_P_N_BUTTON_clicked",
    "on_MUL_PQ_P_BUTTON_clicked",
    "on_DIV_PP_P_BUTTON_clicked",
    "on_MUL_PXK_BUTTON_clicked",
    "on_MOD_PP_P_BUTTON_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      62,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  386,    2, 0x08,    1 /* Private */,
       4,    0,  389,    2, 0x08,    3 /* Private */,
       5,    0,  390,    2, 0x08,    4 /* Private */,
       6,    0,  391,    2, 0x08,    5 /* Private */,
       7,    0,  392,    2, 0x08,    6 /* Private */,
       8,    0,  393,    2, 0x08,    7 /* Private */,
       9,    0,  394,    2, 0x08,    8 /* Private */,
      10,    0,  395,    2, 0x08,    9 /* Private */,
      11,    0,  396,    2, 0x08,   10 /* Private */,
      12,    0,  397,    2, 0x08,   11 /* Private */,
      13,    0,  398,    2, 0x08,   12 /* Private */,
      14,    0,  399,    2, 0x08,   13 /* Private */,
      15,    0,  400,    2, 0x08,   14 /* Private */,
      16,    0,  401,    2, 0x08,   15 /* Private */,
      17,    0,  402,    2, 0x08,   16 /* Private */,
      18,    0,  403,    2, 0x08,   17 /* Private */,
      19,    0,  404,    2, 0x08,   18 /* Private */,
      20,    0,  405,    2, 0x08,   19 /* Private */,
      21,    1,  406,    2, 0x08,   20 /* Private */,
      24,    1,  409,    2, 0x08,   22 /* Private */,
      24,    1,  412,    2, 0x08,   24 /* Private */,
      26,    1,  415,    2, 0x08,   26 /* Private */,
      26,    1,  418,    2, 0x08,   28 /* Private */,
      28,    1,  421,    2, 0x08,   30 /* Private */,
      30,    0,  424,    2, 0x08,   32 /* Private */,
      31,    0,  425,    2, 0x08,   33 /* Private */,
      32,    0,  426,    2, 0x08,   34 /* Private */,
      33,    0,  427,    2, 0x08,   35 /* Private */,
      34,    0,  428,    2, 0x08,   36 /* Private */,
      35,    0,  429,    2, 0x08,   37 /* Private */,
      36,    0,  430,    2, 0x08,   38 /* Private */,
      37,    0,  431,    2, 0x08,   39 /* Private */,
      38,    0,  432,    2, 0x08,   40 /* Private */,
      39,    0,  433,    2, 0x08,   41 /* Private */,
      40,    0,  434,    2, 0x08,   42 /* Private */,
      41,    0,  435,    2, 0x08,   43 /* Private */,
      42,    0,  436,    2, 0x08,   44 /* Private */,
      43,    0,  437,    2, 0x08,   45 /* Private */,
      44,    0,  438,    2, 0x08,   46 /* Private */,
      45,    0,  439,    2, 0x08,   47 /* Private */,
      46,    0,  440,    2, 0x08,   48 /* Private */,
      47,    0,  441,    2, 0x08,   49 /* Private */,
      48,    0,  442,    2, 0x08,   50 /* Private */,
      49,    0,  443,    2, 0x08,   51 /* Private */,
      50,    0,  444,    2, 0x08,   52 /* Private */,
      51,    0,  445,    2, 0x08,   53 /* Private */,
      52,    0,  446,    2, 0x08,   54 /* Private */,
      53,    0,  447,    2, 0x08,   55 /* Private */,
      54,    0,  448,    2, 0x08,   56 /* Private */,
      55,    0,  449,    2, 0x08,   57 /* Private */,
      56,    0,  450,    2, 0x08,   58 /* Private */,
      57,    0,  451,    2, 0x08,   59 /* Private */,
      58,    0,  452,    2, 0x08,   60 /* Private */,
      59,    0,  453,    2, 0x08,   61 /* Private */,
      60,    0,  454,    2, 0x08,   62 /* Private */,
      61,    0,  455,    2, 0x08,   63 /* Private */,
      62,    0,  456,    2, 0x08,   64 /* Private */,
      63,    0,  457,    2, 0x08,   65 /* Private */,
      64,    0,  458,    2, 0x08,   66 /* Private */,
      65,    0,  459,    2, 0x08,   67 /* Private */,
      66,    0,  460,    2, 0x08,   68 /* Private */,
      67,    0,  461,    2, 0x08,   69 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 22,   23,
    QMetaType::Void, 0x80000000 | 25,   23,
    QMetaType::Void, 0x80000000 | 22,   23,
    QMetaType::Void, 0x80000000 | 27,   23,
    QMetaType::Void, 0x80000000 | 25,   23,
    QMetaType::Void, 0x80000000 | 29,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_tabWidget_tabBarClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_pushButton_15_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_COM_NN_D_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_NZER_N_B_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ADD_1N_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ADD_NN_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_SUB_NN_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MOD_NN_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_DIV_NN_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_GCF_NN_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_LCM_NN_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_DIV_NN_Dk_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_SUB_NDN_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MUL_ND_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MUL_Nk_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MUL_NN_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionOpen_Input_File_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionChoose_Output_File_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'write_natural_result'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<NaturalNumber, std::false_type>,
        // method 'write_integer_result'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<IntegerNumber, std::false_type>,
        // method 'write_integer_result'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<NaturalNumber, std::false_type>,
        // method 'write_rational_result'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<RationalNumber, std::false_type>,
        // method 'write_rational_result'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<IntegerNumber, std::false_type>,
        // method 'write_polynomial_result'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Polynomial, std::false_type>,
        // method 'on_actionOpen_Input2_File_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_16_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MUL_ZZ_Z_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ADD_ZZ_Z_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_SUB_ZZ_Z_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ABS_Z_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_TRANS_N_Z_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_TRANS_Z_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_POZ_Z_D_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MUL_ZM_Z_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_DIV_ZZ_Z_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MOD_ZZ_Z_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MUL_QQ_Q_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_INT_Q_B_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_RED_Q_Q_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ADD_QQ_Q_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_TRANS_Z_Q_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_DIV_QQ_Q_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_SUB_QQ_Q_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_TRANS_Q_Z_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_17_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'show_second_rational'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'show_second_integer'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'show_second_natural'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_18_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MUL_PP_P_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_NMR_P_P_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ADD_PP_P_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_SUB_PP_P_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_GCF_PP_P_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_DER_P_P_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_FAC_P_Q_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_LED_P_Q_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_DEG_P_N_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MUL_PQ_P_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_DIV_PP_P_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MUL_PXK_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_MOD_PP_P_BUTTON_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_tabWidget_tabBarClicked((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->on_pushButton_15_clicked(); break;
        case 2: _t->on_COM_NN_D_BUTTON_clicked(); break;
        case 3: _t->on_NZER_N_B_BUTTON_clicked(); break;
        case 4: _t->on_ADD_1N_N_BUTTON_clicked(); break;
        case 5: _t->on_ADD_NN_N_BUTTON_clicked(); break;
        case 6: _t->on_SUB_NN_N_BUTTON_clicked(); break;
        case 7: _t->on_MOD_NN_N_BUTTON_clicked(); break;
        case 8: _t->on_DIV_NN_N_BUTTON_clicked(); break;
        case 9: _t->on_GCF_NN_N_BUTTON_clicked(); break;
        case 10: _t->on_LCM_NN_N_BUTTON_clicked(); break;
        case 11: _t->on_DIV_NN_Dk_BUTTON_clicked(); break;
        case 12: _t->on_SUB_NDN_N_BUTTON_clicked(); break;
        case 13: _t->on_MUL_ND_N_BUTTON_clicked(); break;
        case 14: _t->on_MUL_Nk_N_BUTTON_clicked(); break;
        case 15: _t->on_MUL_NN_N_BUTTON_clicked(); break;
        case 16: _t->on_actionOpen_Input_File_triggered(); break;
        case 17: _t->on_actionChoose_Output_File_triggered(); break;
        case 18: _t->write_natural_result((*reinterpret_cast< std::add_pointer_t<NaturalNumber>>(_a[1]))); break;
        case 19: _t->write_integer_result((*reinterpret_cast< std::add_pointer_t<IntegerNumber>>(_a[1]))); break;
        case 20: _t->write_integer_result((*reinterpret_cast< std::add_pointer_t<NaturalNumber>>(_a[1]))); break;
        case 21: _t->write_rational_result((*reinterpret_cast< std::add_pointer_t<RationalNumber>>(_a[1]))); break;
        case 22: _t->write_rational_result((*reinterpret_cast< std::add_pointer_t<IntegerNumber>>(_a[1]))); break;
        case 23: _t->write_polynomial_result((*reinterpret_cast< std::add_pointer_t<Polynomial>>(_a[1]))); break;
        case 24: _t->on_actionOpen_Input2_File_triggered(); break;
        case 25: _t->on_pushButton_16_clicked(); break;
        case 26: _t->on_MUL_ZZ_Z_BUTTON_clicked(); break;
        case 27: _t->on_ADD_ZZ_Z_BUTTON_clicked(); break;
        case 28: _t->on_SUB_ZZ_Z_BUTTON_clicked(); break;
        case 29: _t->on_ABS_Z_N_BUTTON_clicked(); break;
        case 30: _t->on_TRANS_N_Z_BUTTON_clicked(); break;
        case 31: _t->on_TRANS_Z_N_BUTTON_clicked(); break;
        case 32: _t->on_POZ_Z_D_BUTTON_clicked(); break;
        case 33: _t->on_MUL_ZM_Z_BUTTON_clicked(); break;
        case 34: _t->on_DIV_ZZ_Z_BUTTON_clicked(); break;
        case 35: _t->on_MOD_ZZ_Z_BUTTON_clicked(); break;
        case 36: _t->on_MUL_QQ_Q_BUTTON_clicked(); break;
        case 37: _t->on_INT_Q_B_BUTTON_clicked(); break;
        case 38: _t->on_RED_Q_Q_BUTTON_clicked(); break;
        case 39: _t->on_ADD_QQ_Q_BUTTON_clicked(); break;
        case 40: _t->on_TRANS_Z_Q_BUTTON_clicked(); break;
        case 41: _t->on_DIV_QQ_Q_BUTTON_clicked(); break;
        case 42: _t->on_SUB_QQ_Q_BUTTON_clicked(); break;
        case 43: _t->on_TRANS_Q_Z_BUTTON_clicked(); break;
        case 44: _t->on_pushButton_17_clicked(); break;
        case 45: _t->show_second_rational(); break;
        case 46: _t->show_second_integer(); break;
        case 47: _t->show_second_natural(); break;
        case 48: _t->on_pushButton_18_clicked(); break;
        case 49: _t->on_MUL_PP_P_BUTTON_clicked(); break;
        case 50: _t->on_NMR_P_P_clicked(); break;
        case 51: _t->on_ADD_PP_P_BUTTON_clicked(); break;
        case 52: _t->on_SUB_PP_P_BUTTON_clicked(); break;
        case 53: _t->on_GCF_PP_P_BUTTON_clicked(); break;
        case 54: _t->on_DER_P_P_clicked(); break;
        case 55: _t->on_FAC_P_Q_BUTTON_clicked(); break;
        case 56: _t->on_LED_P_Q_BUTTON_clicked(); break;
        case 57: _t->on_DEG_P_N_BUTTON_clicked(); break;
        case 58: _t->on_MUL_PQ_P_BUTTON_clicked(); break;
        case 59: _t->on_DIV_PP_P_BUTTON_clicked(); break;
        case 60: _t->on_MUL_PXK_BUTTON_clicked(); break;
        case 61: _t->on_MOD_PP_P_BUTTON_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 62)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 62;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 62)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 62;
    }
    return _id;
}
QT_WARNING_POP
